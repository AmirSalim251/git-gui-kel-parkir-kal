/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KalkulatorGUI;
import KalkulatorClass.Kalkulator;

/**
 *
 * @author Windows 10
 */
public class KalkulatorApp {
    public static void main(String[]args){
        Kalkulator obj = new Kalkulator();
        String operand = " ";
        Menu app = new Menu();
        app.setVisible(true);
        app.setLocationRelativeTo(null);
    }
    
}
