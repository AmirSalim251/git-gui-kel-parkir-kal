/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParkirGUI;
import DataStructure.*;
/**
 *
 * @author Windows 10
 */
public class MainApp {
   public static void main(String[] args){
   LinkedList list = new LinkedList();
   MainMenu m = new MainMenu(list);
   m.setVisible(true);
   }
  
    
}
